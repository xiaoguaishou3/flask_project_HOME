# @ Time    : 2020/11/27 20:41
# @ Author  : JuRan


from . import api
from lghome.utils.commons import login_required
from flask import g, request, jsonify
from lghome.response_code import RET
from lghome.libs.image_storage import storage
import logging
from lghome.models import User
from lghome import db
from lghome import constants


@api.route("/users/avatar", methods=["POST"])
@login_required
def set_user_avatar():
    """
    设置用户的头像
    :param: 图片
    :return: avatar_url 头像的地址
    """
    user_id = g.user_id

    # 获取图片
    image_file = request.files.get('avatar')
    # print(image_file)
    # print(type(image_file))

    if image_file is None:
        return jsonify(errno=RET.PARAMERR, errmsg='未上传图片')

    # 图片的二进制数据
    image_data = image_file.read()

    # 上传到七牛云
    try:
        file_name = storage(image_data)
    except Exception as e:
        logging.error(e)
        return jsonify(errno=RET.THIRDERR, errmsg='上传图片失败')

    # 保存到数据库中
    # file_name FoRZHZTBj2xRSDa_Se0Rvx26qm0C
    # URL  http://qkgi1wsiz.hd-bkt.clouddn.com/FoRZHZTBj2xRSDa_Se0Rvx26qm0C
    # 保存 file_name
    # http://qkgi1wsiz.hd-bkt.clouddn.com/
    try:
        User.query.filter_by(id=user_id).update({"avatar_url": file_name})
        db.session.commit()
    except Exception as e:
        # 出现异常回滚
        db.session.rollback()
        logging.error(e)
        return jsonify(errno=RET.DBERR, errmsg='保存图片信息失败')

    avatar_url = constants.QINIU_URL_DOMAIN + file_name
    return jsonify(errno=RET.OK, errmsg='保存成功', data={"avatar_url": avatar_url})



"""
用户头像图片保存的位置
1.服务器
# A B C
# 1.png  都保存  空间浪费 
# 图片重名的问题
2.第三方平台-七牛云
3.自己搭建文件存储系统
- FastDFS 快速分布式文件存储系统  (电商)
- HDFS hapdoop分布式文件系统
"""