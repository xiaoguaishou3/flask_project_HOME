# @ Time    : 2020/11/23 20:01
# @ Author  : JuRan

class A:
    pass


a = A()
print(id(a))
b = A()
print(id(b))


