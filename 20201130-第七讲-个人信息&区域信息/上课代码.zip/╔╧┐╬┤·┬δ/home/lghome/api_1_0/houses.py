# @ Time    : 2020/11/30 20:54
# @ Author  : JuRan

from . import api
from lghome.utils.commons import login_required
from flask import g, request, jsonify, session
from lghome.response_code import RET
from lghome.libs.image_storage import storage
import logging
from lghome.models import Area, House
from lghome import db, redis_store
from lghome import constants
import json


@api.route("/areas")
def get_area_info():
    """获取城区信息"""

    # 用redis中读取数据
    try:
        response_json = redis_store.get("area_info")
    except Exception as e:
        logging.error(e)
    else:
        # redis有缓存数据
        if response_json is not None:
            response_json = json.loads(response_json)
            # print(response_json)
            logging.info('redis cache')
            # return response_json, 200, {"Content-Type": "application/json"}
            return jsonify(errno=RET.OK, errmsg='OK', data=response_json['data'])

    # 查询数据库,读取城区信息
    try:
        area_li = Area.query.all()
    except Exception as e:
        logging.error(e)
        return jsonify(errno=RET.DBERR, errmsg='数据库异常')

    area_dict_li = []
    # print(area_li)
    for area in area_li:
        area_dict_li.append(area.to_dict())

    # 将数据转成json字符串  {key:value} <= dict(key=value)
    # response_dict = dict(errno=RET.OK, errmsg='OK', data=area_dict_li)
    response_dict = dict(data=area_dict_li)
    response_json = json.dumps(response_dict)

    try:
        redis_store.setex("area_info", constants.AREA_INFO_REDIS_CACHE_EXPIRES, response_json)
    except Exception as e:
        logging.error(e)

    # return response_json, 200, {"Content-Type": "application/json"}
    return jsonify(errno=RET.OK, errmsg='OK', data=area_dict_li)


@api.route("/houses/info", methods=["POST"])
@login_required
def save_house_info():
    """
    保存房屋的基本信息
    :return: 保存失败或者保存成功
    {
    "title":"1",
    "price":"1",
    "area_id":"8",
    "address":"1",
    "room_count":"1",
    "acreage":"1",
    "unit":"1",
    "capacity":"1",
    "beds":"1",
    "deposit":"1",
    "min_days":"1",
    "max_days":"1",
    "facility":["2","4"]
    }
    """
    # 发布房源的用户
    user_id = g.user_id

    house_data = request.get_json()
    title = house_data.get("title")  # 房屋名称标题
    price = house_data.get("price")  # 房屋单价
    area_id = house_data.get("area_id")  # 房屋所属城区的编号
    address = house_data.get("address")  # 房屋地址
    room_count = house_data.get("room_count")  # 房屋包含的房间数目
    acreage = house_data.get("acreage")  # 房屋面积
    unit = house_data.get("unit")  # 房屋布局（几室几厅)
    capacity = house_data.get("capacity")  # 房屋容纳人数
    beds = house_data.get("beds")  # 房屋卧床数目
    deposit = house_data.get("deposit")  # 押金
    min_days = house_data.get("min_days")  # 最小入住天数 2
    max_days = house_data.get("max_days")  # 最大入住天数 1
    # facility = house_data.get("facility")  # 设备信息

    # 校验参数
    if not all([title, price, area_id, address, room_count, acreage, unit]):
        return jsonify(errno=RET.PARAMERR, errmsg='参数不完整')

    # 判断价格是否正确
    try:
        price = int(float(price)*100)    # 分
        deposit = int(float(deposit)*100)    # 分
    except Exception as e:
        logging.error(e)
        return jsonify(errno=RET.PARAMERR, errmsg='参数错误')

    # 判断区域ID
    try:
        area = Area.query.get(area_id)
    except Exception as e:
        logging.error(e)
        return jsonify(errno=RET.PARAMERR, errmsg='数据库异常')

    if area is None:
        return jsonify(errno=RET.PARAMERR, errmsg='城区信息有误')

    # 保存房屋信息
    house = House(
        user_id=user_id,
        area_id=area_id,
        title=title,
        price=price,
        address=address,
        room_count=room_count,
        acreage=acreage,
        unit=unit,
        capacity=capacity,
        beds=beds,
        deposit=deposit,
        min_days=min_days,
        max_days=max_days
    )
    # 设施信息






