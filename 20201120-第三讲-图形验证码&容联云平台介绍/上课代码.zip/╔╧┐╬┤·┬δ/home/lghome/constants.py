# @ Time    : 2020/11/20 21:26
# @ Author  : JuRan


# 图片验证码的redis有效期，单位:秒
IAMGE_CODE_REDIS_EXPIRES = 180