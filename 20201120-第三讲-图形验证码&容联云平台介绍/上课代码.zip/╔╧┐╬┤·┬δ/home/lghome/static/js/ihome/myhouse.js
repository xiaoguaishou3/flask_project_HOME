$(document).ready(function(){
    $(".auth-warn").show();
})